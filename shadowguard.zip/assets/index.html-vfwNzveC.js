import"./modulepreload-polyfill-B5Qt9EMX.js";import{g as w,a as h,e as b,P as E,L as S,s as p,f as A,h as T}from"./license-CsKoda8x.js";const f=document.getElementById("app");if(!f)throw new Error("options root missing");const I={SECRET:"Secrets & credentials",EMAIL:"Email addresses",PHONE:"Phone numbers",CREDIT_CARD:"Credit card numbers",SSN:"Social Security Numbers",IBAN:"IBAN",BANK_ACCOUNT:"Bank account / routing numbers",PASSPORT:"Passport numbers",DOB:"Dates of birth",ADDRESS:"Street addresses",IP_ADDRESS:"Private IP addresses",PERSON:"Person names",CUSTOM:"Custom protected terms"},$=["ALLOW","WARN","REDACT","BLOCK"];let s,c,o,l=!1,d=null;async function P(){[s,c]=await Promise.all([w(),h()]),o=b(c),r()}function r(){f.innerHTML=`
    <div class="wrap">
      <header>
        <h1>ShadowGuard Settings</h1>
        <p>Choose how ShadowGuard reacts to each data category, and add terms specific to your organization.</p>
      </header>

      <section class="card">
        <h2>License</h2>
        ${B()}
      </section>

      <section class="card">
        <h2>Policy templates</h2>
        <p class="hint">Apply a starting point, then fine-tune individual categories below.</p>
        <div class="templates">
          ${Object.keys(E).map(t=>`<button data-template="${t}">${t}</button>`).join("")}
        </div>
      </section>

      <section class="card">
        <h2>Category policy <span id="saved-pill-policy" class="saved-pill">Saved</span></h2>
        <p class="hint">Allow, Warn, Redact or Block each type of sensitive data when it's about to be sent to an AI tool.</p>
        <table>
          <thead><tr><th>Category</th><th>Action</th></tr></thead>
          <tbody id="policy-rows"></tbody>
        </table>
      </section>

      <section class="card">
        <h2>Custom protected terms <span id="saved-pill-terms" class="saved-pill">Saved</span></h2>
        <p class="hint">Project names, customer names or codewords that aren't standard PII but matter to your company.</p>
        <div class="term-form">
          <input type="text" id="term-label" placeholder="Label (e.g. Project Falcon)" />
          <input type="text" id="term-pattern" placeholder="Keyword or regex" />
          <label class="checkbox-row"><input type="checkbox" id="term-regex" /> Treat as regex</label>
          <button class="add-btn" id="add-term">Add term</button>
        </div>
        <table>
          <thead><tr><th>Label</th><th>Pattern</th><th></th></tr></thead>
          <tbody id="term-rows"></tbody>
        </table>
      </section>
    </div>
  `,L(),g(),k(),R(),C()}function B(){if(o.status==="active")return`
      <p class="license-status active">✓ Activated${c.customerEmail?` — ${m(c.customerEmail)}`:""}</p>
      <p class="hint">This device has lifetime access. No trial limits apply.</p>
      <button class="remove-btn" id="deactivate-btn">Deactivate this device</button>
    `;const e=o.status==="expired"?'<p class="license-status expired">Your trial has ended — activate a license to resume protection.</p>':`<p class="hint">Free trial — ${o.trialDaysLeft} day${o.trialDaysLeft===1?"":"s"} left. Activate below any time to unlock lifetime access.</p>`,a=`<p class="hint">Don't have a key yet? <a href="${S}" target="_blank" rel="noopener">Get lifetime access — $10</a></p>`;return`
    ${e}
    <div class="term-form">
      <input type="text" id="license-key-input" placeholder="Paste your license key" />
      <button class="add-btn" id="activate-btn" ${l?"disabled":""}>${l?"Activating…":"Activate"}</button>
    </div>
    ${d?`<p class="license-error">${m(d)}</p>`:""}
    ${a}
  `}function C(){var t,e;(t=document.getElementById("activate-btn"))==null||t.addEventListener("click",async()=>{const a=document.getElementById("license-key-input"),n=(a==null?void 0:a.value.trim())??"";if(!n)return;l=!0,d=null,r();const i=await A(n);l=!1,i.ok?(c=await h(),o=b(c)):d=i.error,r()}),(e=document.getElementById("deactivate-btn"))==null||e.addEventListener("click",async()=>{await T(),c=await h(),o=b(c),r()})}function L(){const t=document.getElementById("policy-rows");t.innerHTML=s.policy.map(e=>`
      <tr>
        <td>${I[e.category]}</td>
        <td>
          <select data-category="${e.category}">
            ${$.map(a=>`<option value="${a}" ${a===e.action?"selected":""}>${a}</option>`).join("")}
          </select>
        </td>
      </tr>`).join(""),t.querySelectorAll("select").forEach(e=>{e.addEventListener("change",async a=>{const n=a.target,i=n.dataset.category,y=n.value;s={...s,policy:s.policy.map(v=>v.category===i?{...v,action:y}:v)},await p(s),u("saved-pill-policy")})})}function g(){const t=document.getElementById("term-rows");if(s.customTerms.length===0){t.innerHTML='<tr><td colspan="3"><div class="empty">No custom terms yet.</div></td></tr>';return}t.innerHTML=s.customTerms.map(e=>`
      <tr>
        <td>${m(e.label)}</td>
        <td>${m(e.pattern)}${e.isRegex?" <em>(regex)</em>":""}</td>
        <td><button class="remove-btn" data-remove="${e.id}">Remove</button></td>
      </tr>`).join(""),t.querySelectorAll("[data-remove]").forEach(e=>{e.addEventListener("click",async()=>{const a=e.dataset.remove;s={...s,customTerms:s.customTerms.filter(n=>n.id!==a)},await p(s),g(),u("saved-pill-terms")})})}function k(){document.querySelectorAll("[data-template]").forEach(t=>{t.addEventListener("click",async()=>{const e=t.dataset.template,a=E[e];a&&(s={...s,policy:a.map(n=>({...n}))},await p(s),L(),u("saved-pill-policy"))})})}function R(){var t;(t=document.getElementById("add-term"))==null||t.addEventListener("click",async()=>{const e=document.getElementById("term-label"),a=document.getElementById("term-pattern"),n=document.getElementById("term-regex"),i=a.value.trim();if(!i)return;const y={id:crypto.randomUUID(),label:e.value.trim()||i,pattern:i,isRegex:n.checked};s={...s,customTerms:[...s.customTerms,y]},await p(s),e.value="",a.value="",n.checked=!1,g(),u("saved-pill-terms")})}function u(t){const e=document.getElementById(t);e&&(e.classList.add("visible"),setTimeout(()=>e.classList.remove("visible"),1200))}function m(t){const e=document.createElement("div");return e.textContent=t,e.innerHTML}P();
