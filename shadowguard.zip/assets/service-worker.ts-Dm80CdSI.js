import{g as e,s,D as i,a as n}from"./license-CsKoda8x.js";chrome.runtime.onInstalled.addListener(async a=>{if(a.reason!=="install")return;const t=await e();await s({...i,...t}),await n()});
