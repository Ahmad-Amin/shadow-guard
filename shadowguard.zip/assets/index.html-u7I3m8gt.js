import"./modulepreload-polyfill-B5Qt9EMX.js";import{g as p,j as u,a as v,e as m,s as g}from"./license-CsKoda8x.js";const d=document.getElementById("app");if(!d)throw new Error("popup root missing");async function y(){var a,o,r;const[e,i,t]=await Promise.all([p(),u(),v()]),n=m(t);d.innerHTML=`
    <div class="header">
      <div>
        <h1>ShadowGuard</h1>
        <div class="subtitle">Protecting your AI prompts</div>
      </div>
    </div>
    ${f(n)}
    <div class="toggle-row">
      <div>
        <div class="label">Private AI Mode</div>
        <div class="desc">Aggressively anonymize identifying values before every submission.</div>
      </div>
      <label class="switch">
        <input type="checkbox" id="privacy-toggle" ${e.privacyModeEnabled?"checked":""} />
        <span class="slider"></span>
      </label>
    </div>
    <div class="section-title">What ShadowGuard protected for you</div>
    ${h(i)}
    <a class="footer-link" id="open-options" href="#">Manage policies and custom terms</a>
  `,(a=document.getElementById("privacy-toggle"))==null||a.addEventListener("change",async s=>{const l=s.target.checked;await g({...e,privacyModeEnabled:l})}),(o=document.getElementById("open-options"))==null||o.addEventListener("click",s=>{s.preventDefault(),chrome.runtime.openOptionsPage()}),(r=document.getElementById("open-options-license"))==null||r.addEventListener("click",s=>{s.preventDefault(),chrome.runtime.openOptionsPage()})}function f(e){if(e.status==="active")return"";const i=e.status==="expired",t=i?"Protection paused — activate to resume":`Trial: ${e.trialDaysLeft} day${e.trialDaysLeft===1?"":"s"} left`;return`
    <div class="license-banner ${i?"expired":"trial"}">
      <span>${t}</span>
      <a href="#" id="open-options-license">${i?"Activate":"Upgrade"}</a>
    </div>`}function h(e){return e.length===0?`<div class="empty-state">No risky submissions caught yet. You're all clear.</div>`:`<ul class="activity-list">${e.slice(0,20).map(t=>`
      <li class="activity-item">
        <div class="top-row">
          <span class="site">${c(t.site)}</span>
          <span class="action ${t.action}">${t.overridden?"OVERRIDDEN":t.action}</span>
        </div>
        <div class="meta">${c(t.categories.join(", "))} · ${$(t.timestamp)}</div>
      </li>`).join("")}</ul>`}function $(e){const i=Date.now()-e,t=Math.round(i/6e4);if(t<1)return"just now";if(t<60)return`${t}m ago`;const n=Math.round(t/60);return n<24?`${n}h ago`:new Date(e).toLocaleDateString()}function c(e){const i=document.createElement("div");return i.textContent=e,i.innerHTML}y();
