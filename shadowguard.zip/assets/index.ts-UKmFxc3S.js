var P=Object.defineProperty;var z=(e,n,t)=>n in e?P(e,n,{enumerable:!0,configurable:!0,writable:!0,value:t}):e[n]=t;var E=(e,n,t)=>z(e,typeof n!="symbol"?n+"":n,t);import{b as R,c as O,r as L,i as D,d as $}from"./license-CsKoda8x.js";function g(e){for(const n of e){const t=document.querySelector(n);if(t)return t}return null}function k(e){return e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement?e.value:e.innerText}function T(e,n){if(e instanceof HTMLTextAreaElement||e instanceof HTMLInputElement){Z(e,n);return}H(e,n)}function Z(e,n){var a;const t=e instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,r=(a=Object.getOwnPropertyDescriptor(t,"value"))==null?void 0:a.set;r==null||r.call(e,n),e.dispatchEvent(new Event("input",{bubbles:!0}))}function H(e,n){e.focus();const t=window.getSelection(),r=document.createRange();r.selectNodeContents(e),t==null||t.removeAllRanges(),t==null||t.addRange(r),document.execCommand("insertText",!1,n)||(e.textContent=n,e.dispatchEvent(new InputEvent("input",{bubbles:!0,data:n,inputType:"insertText"})))}const M=["#prompt-textarea",'div[contenteditable="true"][id^="prompt-textarea"]',"textarea[data-mobile-composer-prompt]","#mobile-composer-prompt"],B=['button[data-testid="send-button"]','button[aria-label*="Send" i]'],G=["main [role='presentation']","main"],U={id:"chatgpt",displayName:"ChatGPT",matchesHost:e=>e==="chatgpt.com"||e==="chat.openai.com",findInput:()=>g(M),findSendButton:e=>{var t;const n=g(B);return n||(((t=e.closest("form"))==null?void 0:t.querySelector("button[type='submit']"))??null)},findResponseContainer:()=>g(G),getText:k,setText:T},K=['div[contenteditable="true"].ProseMirror','div[contenteditable="true"][aria-label*="prompt" i]'],W=['button[aria-label*="Send" i]',"button[type='submit']"],q=["div[data-testid='conversation-turns']","main"],Y={id:"claude",displayName:"Claude",matchesHost:e=>e==="claude.ai",findInput:()=>g(K),findSendButton:e=>{var t;const n=g(W);return n||(((t=e.closest("form"))==null?void 0:t.querySelector("button[type='submit']"))??null)},findResponseContainer:()=>g(q),getText:k,setText:T},F=["div.ql-editor[contenteditable='true']","rich-textarea div[contenteditable='true']"],V=["button[aria-label*='Send message' i]","button[aria-label*='Send' i]"],j=["chat-window","main"],J={id:"gemini",displayName:"Gemini",matchesHost:e=>e==="gemini.google.com",findInput:()=>g(F),findSendButton:()=>g(V),findResponseContainer:()=>g(j),getText:k,setText:T},X=[U,Y,J];function Q(e){return X.find(n=>n.matchesHost(e))??null}function ee(e,n){const t=[];for(const r of n){let a;try{a=r.isRegex?new RegExp(r.pattern,"gi"):new RegExp(te(r.pattern),"gi")}catch{continue}let o;for(;(o=a.exec(e))!==null;){if(o[0].length===0){a.lastIndex++;continue}t.push({category:"CUSTOM",severity:"HIGH",label:r.label||"Protected term",value:o[0],start:o.index,end:o.index+o[0].length,reversible:!0})}}return t}function te(e){return e.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}const f="(?:25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)",ne=`\\b(?:10\\.${f}\\.${f}\\.${f}|172\\.(?:1[6-9]|2\\d|3[0-1])\\.${f}\\.${f}|192\\.168\\.${f}\\.${f}|127\\.${f}\\.${f}\\.${f})\\b`,re="(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)[a-z]*",oe=[{category:"EMAIL",severity:"MEDIUM",label:"Email address",regex:/\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b/g,reversible:!0},{category:"PHONE",severity:"MEDIUM",label:"Phone number",regex:/(?:\+\d{1,3}[\s.-]?)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}\b|\+\d{1,3}[\s.-]?\d{2,4}[\s.-]?\d{3,4}[\s.-]?\d{2,4}\b/g,reversible:!0},{category:"SSN",severity:"HIGH",label:"US Social Security Number",regex:/\b\d{3}-\d{2}-\d{4}\b/g,reversible:!0},{category:"CREDIT_CARD",severity:"HIGH",label:"Credit card number",regex:/\b(?:\d[ -]?){13,16}\b/g,reversible:!0,validate:ie},{category:"IBAN",severity:"HIGH",label:"IBAN",regex:/\b[A-Z]{2}\d{2}[A-Z0-9]{10,30}\b/g,reversible:!0},{category:"BANK_ACCOUNT",severity:"HIGH",label:"Bank account / routing number",regex:/\b\d{8,17}\b/g,reversible:!0,contextKeywords:/\b(?:account|acct\.?|routing|aba)\s*(?:number|no\.?|num\.?|#)?\b/i,contextWindow:30},{category:"PASSPORT",severity:"HIGH",label:"Passport number",regex:/\b[A-Za-z]{0,2}\d{6,9}\b/g,reversible:!0,contextKeywords:/\bpassport\b/i,contextWindow:30},{category:"DOB",severity:"HIGH",label:"Date of birth",regex:new RegExp(`\\b(?:\\d{1,2}[/-]\\d{1,2}[/-]\\d{2,4}|\\d{4}-\\d{2}-\\d{2}|${re}\\.?\\s+\\d{1,2},?\\s+\\d{4})\\b`,"g"),reversible:!0,contextKeywords:/\b(?:dob|date of birth|birth\s?date|born on|birthday)\b/i,contextWindow:30},{category:"ADDRESS",severity:"MEDIUM",label:"Street address",regex:/\b\d{1,6}[A-Za-z]?\s+[A-Za-z0-9.'-]+(?:\s+[A-Za-z0-9.'-]+){0,4}\s+(?:Street|St|Avenue|Ave|Boulevard|Blvd|Drive|Dr|Lane|Ln|Road|Rd|Court|Ct|Way|Place|Pl|Square|Sq|Terrace|Ter|Circle|Cir|Parkway|Pkwy|Highway|Hwy)\.?\b(?:,?\s+(?:Apt|Suite|Ste|Unit|#)\.?\s*[\w-]+)?/gi,reversible:!0},{category:"IP_ADDRESS",severity:"MEDIUM",label:"Private IP address",regex:new RegExp(ne,"g"),reversible:!0}];function ae(e){const n=[];for(const t of oe){t.regex.lastIndex=0;let r;for(;(r=t.regex.exec(e))!==null;){const a=r[0];t.validate&&!t.validate(a)||t.contextKeywords&&!se(e,r.index,a.length,t.contextKeywords,t.contextWindow??30)||(n.push({category:t.category,severity:t.severity,label:t.label,value:a,start:r.index,end:r.index+a.length,reversible:t.reversible}),a.length===0&&t.regex.lastIndex++)}}return ce(n)}function se(e,n,t,r,a){const o=e.slice(Math.max(0,n-a),n),s=e.slice(n+t,Math.min(e.length,n+t+a));return r.lastIndex=0,r.test(o)||r.test(s)}function ie(e){const n=e.replace(/[ -]/g,"");if(n.length<13||n.length>19)return!1;let t=0,r=!1;for(let a=n.length-1;a>=0;a--){let o=Number(n[a]);r&&(o*=2,o>9&&(o-=9)),t+=o,r=!r}return t%10===0}function ce(e){const n={CRITICAL:3,HIGH:2,MEDIUM:1,LOW:0},t=[...e].sort((o,s)=>n[s.severity]-n[o.severity]||s.end-s.start-(o.end-o.start)||o.start-s.start),r=[],a=[];for(const o of t)a.some(([s,u])=>o.start<u&&o.end>s)||(a.push([o.start,o.end]),r.push(o));return r.sort((o,s)=>o.start-s.start)}const le=[{label:"Anthropic API key",regex:/\bsk-ant-[A-Za-z0-9_-]{20,}\b/g},{label:"OpenAI API key",regex:/\bsk-(?!ant-)(?:proj-)?[A-Za-z0-9_-]{20,}\b/g},{label:"Google API key",regex:/\bAIza[A-Za-z0-9_-]{35}\b/g},{label:"Hugging Face token",regex:/\bhf_[A-Za-z0-9]{20,}\b/g},{label:"Stripe live secret key",regex:/\bsk_live_[A-Za-z0-9]{16,}\b/g},{label:"Stripe live publishable key",regex:/\bpk_live_[A-Za-z0-9]{16,}\b/g},{label:"Stripe restricted key",regex:/\brk_live_[A-Za-z0-9]{16,}\b/g},{label:"Square access token",regex:/\bsq0(?:atp|csp)-[A-Za-z0-9_-]{20,}\b/g},{label:"PayPal/Braintree access token",regex:/\baccess_token\$production\$[A-Za-z0-9]{16}\$[A-Za-z0-9]{32}\b/g},{label:"AWS access key ID",regex:/\b(?:AKIA|ASIA)[A-Z0-9]{16}\b/g},{label:"AWS secret access key",regex:/\b(?:aws_secret_access_key|secret[_-]?access[_-]?key)\s*[:=]\s*["']?([A-Za-z0-9/+=]{40})["']?/gi},{label:"Azure Storage account key",regex:/\bAccountKey=([A-Za-z0-9+/]{86}==)/g},{label:"Azure Storage connection string",regex:/\bDefaultEndpointsProtocol=https?;AccountName=[^;]+;AccountKey=[A-Za-z0-9+/]{86}==/g},{label:"GCP service account private key",regex:/"private_key":\s*"(-----BEGIN PRIVATE KEY-----[^"]+)"/g},{label:"GitHub token",regex:/\bgh[pousr]_[A-Za-z0-9]{20,}\b/g},{label:"GitLab personal access token",regex:/\bglpat-[A-Za-z0-9_-]{20,}\b/g},{label:"npm access token",regex:/\bnpm_[A-Za-z0-9]{30,}\b/g},{label:"PyPI upload token",regex:/\bpypi-AgEIcHlwaS5vcmc[A-Za-z0-9_-]{20,}\b/g},{label:"Slack token",regex:/\bxox[baprs]-[A-Za-z0-9-]{10,}\b/g},{label:"Slack webhook URL",regex:/\bhooks\.slack\.com\/services\/T[A-Z0-9]+\/B[A-Z0-9]+\/[A-Za-z0-9]+/g},{label:"Discord bot token",regex:/\b[MNO][A-Za-z0-9_-]{23,25}\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{27,38}\b/g},{label:"Twilio Account SID",regex:/\bAC[a-f0-9]{32}\b/g},{label:"SendGrid API key",regex:/\bSG\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\b/g},{label:"Mailgun API key",regex:/\bkey-[a-f0-9]{32}\b/g},{label:"JSON Web Token (JWT)",regex:/\beyJ[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{10,}\b/g},{label:"Private key block",regex:/-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----/g},{label:"Database connection string",regex:/\b(?:postgres|postgresql|mysql|mongodb(?:\+srv)?|redis|amqp|mssql):\/\/[^\s"']+:[^\s"']+@[^\s"']+/gi},{label:"Bearer token",regex:/\bAuthorization:\s*Bearer\s+([A-Za-z0-9\-._~+/]{20,}=*)/gi},{label:"Generic password assignment",regex:new RegExp(`(?<![A-Za-z])(?:password|passwd|pwd)\\s*[:=]\\s*["']?([^"'\\s]{6,})["']?`,"gi")},{label:"Generic API key/token assignment",regex:new RegExp(`(?<![A-Za-z])(?:api[_-]?key|api[_-]?token|access[_-]?token|secret[_-]?key|client[_-]?secret|refresh[_-]?token)\\s*[:=]\\s*["']?([A-Za-z0-9_\\-./+]{16,})["']?`,"gi")}];function de(e){const n=[];for(const t of le){t.regex.lastIndex=0;let r;for(;(r=t.regex.exec(e))!==null;){const a=r[1]??r[0],o=r[1]?r[0].indexOf(r[1])+r.index:r.index;n.push({category:"SECRET",severity:"CRITICAL",label:t.label,value:a,start:o,end:o+a.length,reversible:!1}),r[0].length===0&&t.regex.lastIndex++}}return ue(n)}function ue(e){const n=[...e].sort((a,o)=>a.start-o.start||o.end-a.end),t=[];let r=-1;for(const a of n)a.start>=r&&(t.push(a),r=a.end);return t}const w={CRITICAL:3,HIGH:2,MEDIUM:1,LOW:0};function pe(e,n){if(!e.trim())return{matches:[],highestSeverity:null};const t=de(e),r=t.map(i=>[i.start,i.end]),a=ae(e).filter(i=>!I(i,r)),o=ee(e,n).filter(i=>!I(i,r)),s=[...t,...a,...o].sort((i,p)=>i.start-p.start),u=s.reduce((i,p)=>!i||w[p.severity]>w[i]?p.severity:i,null);return{matches:s,highestSeverity:u}}function I(e,n){return n.some(([t,r])=>e.start<r&&e.end>t)}const N={BLOCK:3,REDACT:2,WARN:1,ALLOW:0};function be(e,n){let t="ALLOW";for(const r of e.matches){const a=n.find(s=>s.category===r.category),o=(a==null?void 0:a.action)??"WARN";N[o]>N[t]&&(t=o)}return t}const fe=`
  :host {
    all: initial;
  }
  .panel {
    position: fixed;
    z-index: 2147483647;
    bottom: 96px;
    right: 24px;
    width: 340px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: #ffffff;
    color: #13233f;
    border-radius: 12px;
    box-shadow: 0 12px 32px rgba(15, 30, 60, 0.24);
    border: 1px solid #dfe6f1;
    overflow: hidden;
    animation: shadowguard-slide-in 160ms ease-out;
  }
  @keyframes shadowguard-slide-in {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .header {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 12px 14px;
    background: #13233f;
    color: #ffffff;
  }
  .header .dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #ff5c5c;
  }
  .header .dot.warn { background: #f5b700; }
  .header .dot.redact { background: #3a86ff; }
  .header strong {
    font-size: 13px;
    letter-spacing: 0.02em;
  }
  .body {
    padding: 12px 14px;
    max-height: 220px;
    overflow-y: auto;
  }
  .summary {
    font-size: 12.5px;
    color: #4a5a78;
    margin: 0 0 8px;
  }
  .match-list {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .match-list li {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    font-size: 12.5px;
    padding: 6px 8px;
    border-radius: 8px;
    background: #f4f7fc;
  }
  .badge {
    font-size: 10.5px;
    font-weight: 600;
    padding: 2px 6px;
    border-radius: 999px;
    text-transform: uppercase;
    letter-spacing: 0.03em;
  }
  .badge.CRITICAL { background: #ffe1e1; color: #a4121a; }
  .badge.HIGH { background: #ffe9cc; color: #a4560c; }
  .badge.MEDIUM { background: #e1ecff; color: #1a4fa4; }
  .badge.LOW { background: #eaeaea; color: #555; }
  .footer {
    display: flex;
    gap: 8px;
    padding: 12px 14px;
    border-top: 1px solid #eef1f6;
  }
  button {
    font: inherit;
    font-size: 12.5px;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    padding: 8px 10px;
    cursor: pointer;
    flex: 1;
  }
  button.primary {
    background: #13233f;
    color: #ffffff;
  }
  button.primary:hover { background: #1c3357; }
  button.secondary {
    background: #f0f2f6;
    color: #13233f;
  }
  button.secondary:hover { background: #e3e7ef; }
  button.ghost {
    background: transparent;
    color: #7a8aa8;
  }
  button.ghost:hover { color: #4a5a78; }
  .explain {
    font-size: 11.5px;
    color: #7a8aa8;
    margin: 8px 0 0;
    line-height: 1.4;
  }
`,ge={SECRET:"Credentials and API keys should never be submitted to a public AI tool.",SSN:"Social Security Numbers are high-risk identifiers under most company policies.",CREDIT_CARD:"Card numbers are financial data and should be redacted before sending.",BANK_ACCOUNT:"Bank account and routing numbers are financial data and should be redacted before sending.",PASSPORT:"Passport numbers are government identifiers and are treated as high-risk.",DOB:"Dates of birth combined with other details can be used for identity theft.",ADDRESS:"Street addresses are personal data and should be redacted before sending.",IP_ADDRESS:"Private/internal IP addresses can reveal details about your network.",CUSTOM:"This matches a term your organization has marked as confidential."};let m=null;function me(e){return he("cancel"),new Promise(n=>{const t=document.createElement("div");t.setAttribute("data-shadowguard-panel",""),document.body.appendChild(t);const r=t.attachShadow({mode:"open"}),a=document.createElement("style");a.textContent=fe,r.appendChild(a);const o=document.createElement("div");o.className="panel",o.appendChild(ye(e)),o.appendChild(xe(e)),o.appendChild(Ae(e,i=>u(i))),r.appendChild(o);const s=i=>{i.key==="Escape"&&u("cancel")};document.addEventListener("keydown",s,!0);function u(i){document.removeEventListener("keydown",s,!0),t.remove(),(m==null?void 0:m.host)===t&&(m=null),n(i)}m={host:t,resolve:u}})}function he(e){m==null||m.resolve(e)}function ye(e){const n=document.createElement("div");n.className="header";const t=document.createElement("span");t.className=`dot ${e.effectiveAction==="WARN"?"warn":""}`,n.appendChild(t);const r=document.createElement("strong");return r.textContent=e.effectiveAction==="BLOCK"?"ShadowGuard blocked this submission":"ShadowGuard detected sensitive data",n.appendChild(r),n}function xe(e){const n=document.createElement("div");n.className="body";const t=document.createElement("p");t.className="summary",t.textContent=`Before sending to ${e.siteName}, ShadowGuard found ${e.matches.length} item${e.matches.length===1?"":"s"} that match your organization's policy:`,n.appendChild(t);const r=document.createElement("ul");r.className="match-list";for(const o of Se(e.matches))r.appendChild(Ee(o));n.appendChild(r);const a=ve(e.matches);if(a){const o=document.createElement("p");o.className="explain",o.textContent=a,n.appendChild(o)}return n}function Ee(e){const n=document.createElement("li"),t=document.createElement("span");t.textContent=`${e.label} — ${Ce(e.value)}`,n.appendChild(t);const r=document.createElement("span");return r.className=`badge ${e.severity}`,r.textContent=e.severity,n.appendChild(r),n}function Ae(e,n){const t=document.createElement("div");return t.className="footer",e.effectiveAction==="BLOCK"?(t.appendChild(A("Edit Prompt","primary",()=>n("cancel"))),t):(t.appendChild(A("Send Anyway","primary",()=>n("send_anyway"))),t.appendChild(A("Cancel","ghost",()=>n("cancel"))),t)}function A(e,n,t){const r=document.createElement("button");return r.className=n,r.textContent=e,r.addEventListener("click",t),r}function Se(e){const n=new Set,t=[];for(const r of e){const a=`${r.category}:${r.label}:${r.value}`;n.has(a)||(n.add(a),t.push(r))}return t}function ve(e){for(const n of e){const t=ge[n.category];if(t)return t}return null}function Ce(e){return e.length<=6?"•".repeat(e.length):`${e.slice(0,3)}${"•".repeat(Math.min(6,e.length-5))}${e.slice(-2)}`}const ke=`
  :host { all: initial; }
  .toast {
    position: fixed;
    z-index: 2147483647;
    bottom: 96px;
    right: 24px;
    max-width: 320px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 12.5px;
    line-height: 1.4;
    background: #13233f;
    color: #ffffff;
    border-radius: 10px;
    padding: 12px 14px;
    box-shadow: 0 12px 32px rgba(15, 30, 60, 0.24);
    animation: shadowguard-toast-in 160ms ease-out;
  }
  @keyframes shadowguard-toast-in {
    from { opacity: 0; transform: translateY(8px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .action {
    display: block;
    margin-top: 8px;
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.4);
    color: #ffffff;
    border-radius: 6px;
    padding: 4px 10px;
    font-size: 12px;
    font-family: inherit;
    cursor: pointer;
  }
  .action:hover { background: rgba(255, 255, 255, 0.12); }
`;function C(e,n,t=8e3){const r=typeof n=="object"?n:void 0,a=typeof n=="number"?n:t,o=document.createElement("div");o.setAttribute("data-shadowguard-toast",""),document.body.appendChild(o);const s=o.attachShadow({mode:"open"}),u=document.createElement("style");u.textContent=ke,s.appendChild(u);const i=document.createElement("div");if(i.className="toast",i.textContent=e,s.appendChild(i),r){const p=document.createElement("button");p.className="action",p.textContent=r.label,p.addEventListener("click",()=>{o.remove(),r.onClick()}),i.appendChild(p)}setTimeout(()=>o.remove(),a)}function Te(e,n){let t=!1,r=null;const a=c=>{if(c.key!=="Enter"||c.shiftKey||c.isComposing)return;const l=e.findInput();if(!l||!_(c,l)||u())return;const d=i(l);d!==null&&(c.preventDefault(),c.stopImmediatePropagation(),p(l,d,()=>{s(5e3),l.dispatchEvent(new KeyboardEvent("keydown",{key:"Enter",bubbles:!0,cancelable:!0}))}))},o=c=>{const l=e.findInput();if(!l)return;const d=e.findSendButton(l);if(!d||!_(c,d)||u())return;const b=i(l);b!==null&&(c.preventDefault(),c.stopImmediatePropagation(),p(l,b,()=>{s(5e3),d.click()}))};function s(c){t=!0,r&&clearTimeout(r),r=setTimeout(()=>{t=!1,r=null},c)}function u(){return t?(t=!1,r&&(clearTimeout(r),r=null),!0):!1}function i(c){const l=e.getText(c);if(!l.trim()||R().status==="expired")return null;const d=O(),b=pe(l,d.customTerms);if(b.matches.length===0)return null;const y=be(b,d.policy);return y==="ALLOW"?null:{text:l,effectiveAction:y,detection:b}}function p(c,{text:l,effectiveAction:d,detection:b},y){const x=b.matches.map(h=>h.category);if(d==="REDACT"){const h=n.redact(l,b.matches);e.setText(c,h),C(`Redacted ${b.matches.length} item${b.matches.length===1?"":"s"} (${we(x)}). Review your draft, then send it yourself.`,{label:"Send anyway",onClick:()=>{e.setText(c,l),s(15e3),C("Original text restored — press Enter/Send within 15s to submit it as-is.",4e3),S(e,x,d,!0)}}),S(e,x,d,!1);return}(async()=>{const h=await me({siteName:e.displayName,matches:b.matches,effectiveAction:d});await S(e,x,d,h==="send_anyway"),h==="send_anyway"&&y()})()}return document.addEventListener("keydown",a,!0),document.addEventListener("click",o,!0),()=>{document.removeEventListener("keydown",a,!0),document.removeEventListener("click",o,!0)}}function _(e,n){return e.target instanceof Node&&n.contains(e.target)}function we(e){return Array.from(new Set(e)).map(n=>n.toLowerCase().replace(/_/g," ")).join(", ")}async function S(e,n,t,r){const a={id:crypto.randomUUID(),timestamp:Date.now(),site:e.displayName,categories:Array.from(new Set(n)),action:t,overridden:r};await L(a)}class Ie{constructor(){E(this,"counters",{});E(this,"byPlaceholder",new Map);E(this,"byOriginal",new Map)}redact(n,t){if(t.length===0)return n;const r=[...t].sort((o,s)=>s.start-o.start);let a=n;for(const o of r){const s=o.reversible?this.placeholderFor(o):this.stripToken(o);a=a.slice(0,o.start)+s+a.slice(o.end)}return a}placeholderFor(n){const t=`${n.category}:${n.value}`,r=this.byOriginal.get(t);if(r)return r;const a=(this.counters[n.category]??0)+1;this.counters[n.category]=a;const o=`[${n.category}_${a}]`;return this.byPlaceholder.set(o,{placeholder:o,original:n.value,category:n.category}),this.byOriginal.set(t,o),o}stripToken(n){return`[${n.category}_REMOVED]`}restore(n){if(this.byPlaceholder.size===0)return n;let t=n;for(const r of this.byPlaceholder.values())t=t.split(r.placeholder).join(r.original);return t}get mappingSize(){return this.byPlaceholder.size}clear(){this.counters={},this.byPlaceholder.clear(),this.byOriginal.clear()}}function Ne(e,n){let t=null;const r=new MutationObserver(()=>{n.mappingSize!==0&&((!t||!t.isConnected)&&(t=e.findResponseContainer()),t&&_e(t,n,e.findInput()))});return r.observe(document.body,{childList:!0,subtree:!0,characterData:!0}),()=>r.disconnect()}function _e(e,n,t){const r=document.createTreeWalker(e,NodeFilter.SHOW_TEXT);let a=r.nextNode();for(;a;){if(t!=null&&t.contains(a)){a=r.nextNode();continue}const o=a.textContent;if(o&&o.includes("[")){const s=n.restore(o);s!==o&&(a.textContent=s)}a=r.nextNode()}}const v=Q(location.hostname);if(v){D();const e=new Ie;Te(v,e),Ne(v,e),$().then(()=>{R().status==="expired"&&C("Your ShadowGuard trial has ended — open the extension popup to activate your license and resume protection.",8e3)})}
