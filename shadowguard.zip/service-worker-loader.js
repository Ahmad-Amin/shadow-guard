import './assets/service-worker.ts-Dm80CdSI.js';
